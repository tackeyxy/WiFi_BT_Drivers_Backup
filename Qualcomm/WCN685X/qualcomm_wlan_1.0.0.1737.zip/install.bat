@ECHO OFF
ECHO. 
ECHO *** Installing Qualcomm WLAN Win10 driver ***

SET INSTALLPATH=%~dp0

pnputil.exe /add-driver "%INSTALLPATH%\Drivers\*.inf" /subdirs /install

SET EXITCODE=%errorlevel%

IF %EXITCODE% EQU 0 GOTO EXIT0
IF %EXITCODE% EQU 259 GOTO EXIT259
IF %EXITCODE% EQU 1641 GOTO EXIT1641
IF %EXITCODE% EQU 3010 GOTO EXIT3010

:EXIT0
ECHO *** The driver installed successfully! *** 
GOTO END

:EXIT259
ECHO *** Best driver version for your device is already installed! *** 
GOTO END

:EXIT1641
ECHO *** Installation is complete and reboot will start soon! *** 
GOTO END

:EXIT3010
ECHO *** Installation is complete but reboot is required! *** 
GOTO END

:END

